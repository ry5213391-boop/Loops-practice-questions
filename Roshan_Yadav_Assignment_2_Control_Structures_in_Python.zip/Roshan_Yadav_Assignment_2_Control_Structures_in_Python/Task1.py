# to check if a number is even or odd

num = int(input("Enter a number: ")) #user_input converted to int

if (num%2==0): #modulo operator checking remainder is 0 or not
    print(f"{num} is an even number.")
else:
    print(f"{num} is an odd number.")