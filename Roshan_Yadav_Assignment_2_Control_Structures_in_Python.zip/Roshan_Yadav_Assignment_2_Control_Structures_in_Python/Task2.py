# sum of integers from 1 to 50 using a loop

sum = 0 #declaring a variable named sum
for i in range(1, 51): #range is fro 1 ro 51 because 51 will be excluded
    sum += i
print(f"The sum of numbers from 1 to 50 is: {sum}")
    
